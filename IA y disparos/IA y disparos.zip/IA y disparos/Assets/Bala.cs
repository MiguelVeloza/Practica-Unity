using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bala : MonoBehaviour
{

    public void Start()
    {
 
    }

    private void Update()
    {

    }
}
